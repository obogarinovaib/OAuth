from json import load
from time import sleep
from oauth_requests import OAuthSession

def non_brokerage_call_operations(session: OAuthSession):
    line_terminator = "\n\n"
    print(session.get_user_details(), end=line_terminator)
    #print(session.get_list_of_md_subscriptions(), end=line_terminator)
    print(session.get_secdef_by_conid([265598, 8314]), end=line_terminator)
    print(session.get_stocks_by_symbol(["AAPL", "MSFT"]), end=line_terminator)

def iserver_operations(session: OAuthSession):
    session.init_brokerage_session()
    session.get_list_of_brokerage_accounts() # This step is required in order to make market data snapshot requests
    sleep(2) # Sleep for a short while to ensure brokerage session has been initialized
    num_requests = 0
    max_num_snapshot_request = 3
    time_between_requests = 5
    while num_requests < max_num_snapshot_request:
        print(session.get_md_snapshot([265598, 8314], [84, 85, 86, 88]), end="\n\n")
        sleep(time_between_requests) if max_num_snapshot_request > 1 else None
        num_requests += 1
    print(session.get_historical_md_data(8314, "1m", "1d"))

def main(config_data: dict, live_session_token: str = None, live_session_token_expiration: int = None):
    session = OAuthSession(config_data, live_session_token, live_session_token_expiration)
    session.request_live_session_token()
    non_brokerage_call_operations(session)
    iserver_operations(session)

if __name__=="__main__":
    CONFIG = "test_config.json"
    live_session_token = None # Update with the obtained live session token, instead of constantly requesting a new one
    live_session_token_expiration = None
    with open(CONFIG, "r") as config_file:
        config_data = load(config_file)
    main(config_data, live_session_token, live_session_token_expiration)