# Getting Started

0. (NOT REQUIRED, BUT HIGHLY RECOMMENDED) Create and activate a new virtual environment by running `python -m venv venv` followed by `venv/scripts/activate`.
1. Install project dependencies by running `pip install -r requirements.txt`.
2. Create a new JSON config file for the app (see section below for required format).
3. Substitute the config file field `path-to-your-app-config` in the `demo.py` file with the path to your config file.
4. Run the demo.

# Creating a new config file

The config file is in the format:

{
    "realm": "limited_poa",
    "encryption_key_fp": "path-to-private-encryption-key",
    "signature_key_fp": "path-to-private-signature-key",
    "consumer_key": "your-consumer-key",
    "dh_prime": "generated-dh-prime-in-hex",
    "access_token": "your-access-token-from-self-service-portal",
    "access_token_secret": "your-access-token-secret-from-self-service-portal"
}

To get the DH prime in hex you can run the following command passing in the generated `dhparam.pem` file as argument: `openssl asn1parse -in dhparam.pem`